package com.example.ReadMark;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo7735ApplicationTests {

	@Test
	void contextLoads() {
	}

}
