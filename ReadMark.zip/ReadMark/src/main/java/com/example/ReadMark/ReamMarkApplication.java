package com.example.ReadMark;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReamMarkApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReamMarkApplication.class, args);
	}

}
